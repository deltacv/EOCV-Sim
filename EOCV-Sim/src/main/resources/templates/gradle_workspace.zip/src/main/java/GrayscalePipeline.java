import org.opencv.core.Mat;
import org.opencv.imgproc.Imgproc;
import org.openftc.easyopencv.OpenCvPipeline;

public class GrayscalePipeline extends OpenCvPipeline {

    @Override
    public Mat processFrame(Mat inputMat) {
        Imgproc.cvtColor(inputMat, inputMat, Imgproc.COLOR_RGB2GRAY);
        return inputMat;
    }
    
}